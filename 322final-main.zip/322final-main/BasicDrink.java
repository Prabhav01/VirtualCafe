public class BasicDrink extends Drink {
    @Override
    public String getDescription() {
        return "";
    }

    @Override
    public double getCost() {
        return 0.0;
    }
}
