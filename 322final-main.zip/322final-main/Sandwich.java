abstract class Sandwich {
    public abstract String getDescription();
    public abstract double getCost();
}
